package Code.Enum;

public enum ArgType {
    Int,Float,String
}
