package Code.Enum;

public enum Degree {
    low,mid,high
}
