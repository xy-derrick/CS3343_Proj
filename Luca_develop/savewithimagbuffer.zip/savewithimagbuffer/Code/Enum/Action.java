package Code.Enum;

public enum Action {
    up,down,on,off
}
