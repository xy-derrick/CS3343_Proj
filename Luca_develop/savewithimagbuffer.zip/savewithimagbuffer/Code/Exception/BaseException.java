package Code.Exception;

public class BaseException extends Exception {
    public BaseException()
    {
        super();
    }

    public BaseException(String msg)
    {
        super(msg);
    }
}
