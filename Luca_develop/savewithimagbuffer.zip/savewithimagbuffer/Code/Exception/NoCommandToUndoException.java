package Code.Exception;

public class NoCommandToUndoException extends Exception{
    public NoCommandToUndoException()
    {
        String msg = "There is no command to undo !";
        System.out.println(msg);
    }
}
