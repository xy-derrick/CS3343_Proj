package Code.Exception;

public class OrderImageNotMovedException extends BaseException {
    public OrderImageNotMovedException()
    {
        super();
    }

    public OrderImageNotMovedException(String msg)
    {
        super(msg);
    }
}
