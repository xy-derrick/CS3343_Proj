package Code.Exception;

public class NoValidOperationException extends Exception {
}
