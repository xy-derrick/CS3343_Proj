package Code.Command.Base;

public interface CommandNoncancelabe {
}
