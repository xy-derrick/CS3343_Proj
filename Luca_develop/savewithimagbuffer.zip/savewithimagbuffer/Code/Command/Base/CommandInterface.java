package Code.Command.Base;

public interface CommandInterface {
    public abstract void execute();
    public abstract void undo();
}
